#__name__ = '.'.join(__name__.split('/'))
#__package__ = '.'.join('.'.join(__name__.split('/')).split('.')[:-1]) 
if___name__==___index__",index()

import boto3
from .script.createFile import create_file
from .script.configuration import filename,bucketname,key_value

def lambda_handler(event,context):
  client = boto3.client('ssm') 
  s3client = boto3.client('s3')
  response = client.get_parameter(Name='/my-app/dev/db-url',WithDecryption=True)
  kvalue = response['Parameter']['Value']
  filetoupload =  create_file(1,filename,kvalue)  
  s3client.upload_file(filetoupload,bucketname,key_value)
 