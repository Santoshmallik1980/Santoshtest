def create_file (size,file_name,filecontent):
    fName = file_name
    with open(fName, 'w') as f:
        f.write(str(filecontent) * size)
        return fName