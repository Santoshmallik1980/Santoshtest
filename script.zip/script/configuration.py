# Path to create a file 
filename = r"/tmp/secrets_new_Value.txt"
bucketname = 'secrets-lambda-parameter'
key_value =  'secrets_new_Value.txt'